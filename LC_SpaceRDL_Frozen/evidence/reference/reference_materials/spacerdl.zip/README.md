# SMART-QSO SpaceRDL 需求规约

- **项目**: SMART-QSO 1U CubeSat（星载 AI 管理业余无线电应答机）
- **分析范围**: OBC 飞行软件及其与 EPS / RF / ADCS / Jetson 载荷 / 地面站（系统边界外）的交互
- **生成日期**: 2026-10-09
- **生成方式**: `req-to-spacerdl` 技能，从项目需求文档、接口 ICD、运维手册、硬件设计、预算分析与飞行软件源代码逆向提炼

## 交付物

| 文件 | 内容 |
|---|---|
| `requirements.md` | 66 条规范化需求（REQ-001~066），保留父需求 ID（MRD/SYS/SRS），含证据、算子、置信度、状态 |
| `resources.md` | 资源目录：1 控制器、8 设备/外部系统、1 数据元素表、4 算法条目（FormulaTable.B1-B3 + 载荷侧 TinyLM）、2 协议条目（ProTable.B1/B2）、端口 |
| `statements.md` | 31 条 SpaceRDL 语句（ST-001~031）与 REQ 的逐条映射，附软件需求映射要点 |
| `traceability.md` | 来源证据 → REQ → 语句 → code.rdl 位置的四向追踪矩阵 |
| `code.rdl` | 已核实内容组成的 SpaceRDL 规约（InitTask/AppTask/InterruptTask/SystemConstraints） |
| `issues.md` | 40 条待确认问题（冲突、缺失、未接线），按阻塞级别分级 |

## 规范性来源与优先级

1. **正式需求**: docs/requirements/MISSION_REQUIREMENTS.md、SYSTEM_REQUIREMENTS.md（MRD/SYS 体系；注意 REQUIREMENTS_TRACEABILITY.md 的编号与正式文档不匹配 → ISSUE-021）
2. **PDR 基线**: docs/pdr/SMART-QSO_PDR.md（数值与目标的最新最全来源，亦含内部矛盾 → ISSUE-034）
3. **接口协议**: docs/interfaces/ICD_*.md（协议、寄存器、时序、帧格式）
4. **运维文档**: docs/operations/（命令/遥测词典、任务规则、在轨测试、EOL）
5. **设计/预算**: docs/hardware/*、docs/ML_MODELS.md、docs/BEACON_SPEC.md、docs/environment/*
6. **源代码**: software/flight/（可观察行为证据；函数名不作为业务语义的唯一依据）

证据强度按上述顺序取用；代码与文档冲突时保留冲突并记入 issues.md，不替用户选边。

## 系统总览（SpaceRDL 建模结果）

- **控制器**: `obc`（OBC，控制周期 1000ms，依据 ICD 一致证据；代码 20ms 主循环冲突见 ISSUE-015）
- **设备**: `eps`（I2C 0x48）、`rf`（SPI Si4463）、`adcs`（I2C+PWM）、`jetson`（UART 115200）、`wdt`（IWDG）、`hdrm`（烧线+部署开关）、`fram`（FRAM 128KB）
- **外部系统**: `ground`（地面站网，ProTC/ProTM 对象）
- **任务**: InitTask（30s 初始化序列）、AppTask（1s 主控制 + 10s 健康检查 + 2s 持久化 + 60s 遥测/信标 + 遥控 + 部署 + EOL）、InterruptTask（10s 喂狗 + 30min RF 抑制解除）
- **算法**: B-dot（B1）、太阳指向（B2）、功率预测 LSTM（B3，中置信度）
- **协议**: AX.25 UI 下行（ProTable.B1）、上行命令（ProTable.B2，三套方案冲突 ISSUE-001）

## 需求覆盖统计（按 REQ-ID 计算）

| 状态 | 数量 | 占比 |
|---|---|---|
| mapped（已映射到语句） | 46 | 69.7% |
| constraint-only（仅映射为约束） | 10 | 15.2% |
| uncovered（未覆盖，有 ISSUE） | 9 | 13.6% |
| conflict（原文冲突，未选边） | 1 | 1.5% |
| **合计** | **66** | 100% |

语句总数 31 条（ST-001~031）。覆盖率按需求 ID 统计，不用语句数量冒充覆盖率。

## 方言与命名说明

- 能力引用统一使用 **`ReqCapByTable`**（工程拼写）；项目内无既有 SpaceRDL 资产，此为首次生成，无兼容性问题。
- 时间单位统一 `ms`；控制周期与触发时刻来自原文（1000ms 周期、60s 信标、10s 健康检查、2s 持久化、30min RF 抑制、10s 喂狗）。
- `Init` 的配置结构名（EpsI2CConfig 等）为生成占位标识，项目资源库尚未建立 → ISSUE-025，代码中已注释标明。
- 所有 `Compute` 均引用 `FormulaTable.B1~B3`，条目定义在 resources.md RES-010~012；无公式依据的"计算"（QSO 公平性、区域需求预测）未生成语句（ISSUE-031/032）。

## 静态验证状态: **partial**

- `scripts/validate_spacerdl.py` 检查 `code.rdl`: **0 error, 0 warning**（必要区块、括号、分号、Import、设备/控制器唯一性、算子参数、FormulaTable/ProTable 引用、任务块放置均通过）。
- 结构验证通过不等于业务语义正确：66 条需求中 9 条未覆盖、1 条冲突、多个语句标 partial（证据为"设计文档有、代码未接线"）。
- 阻塞问题共 **40 条**（ISSUE-001~040），其中**高阻塞 15 条**：ISSUE-001（命令帧三套）、002（遥测帧两套）、003（上行存在性）、004（EPS 物理层）、006（调制）、008（信标间隔）、009（信标格式）、011（电池拓扑）、012（SOC 阈值）、013（看门狗超时）、014（热阈值）、021（RTM 编号）、024（FreeRTOS 架构）、025（模块未接线）、034（联邦学习矛盾）；中阻塞 20 条、低阻塞 5 条。

## 下一步（需要任务方确认的事项，按优先级）

1. **裁决命令/遥测帧标准**（ISSUE-001/002）：冻结唯一上行/下行帧格式，回填 ProTable.B2 与下行载荷布局。
2. **裁决任务形态**（ISSUE-003/034）：仅信标 vs 带上行；是否保留在轨模型更新。
3. **统一阈值表**（ISSUE-012/013/014/008）：SOC/看门狗/热/信标间隔各裁决单一权威值。
4. **确定代码基线**（ISSUE-024/025）：FreeRTOS 迁移路线 + 模块集成计划，完成后可把 partial 语句升为 verified。
5. **补齐模型规格**（ISSUE-031/032/033）：QSO 优先级、区域需求、功率预测的 I/O 与公式。
6. **IARU 呼号与频率**（ISSUE-007/010）：登记后回填。

## 重新生成说明

本目录由 `req-to-spacerdl` 技能一次性生成；证据采集覆盖 4 个并行探查域（飞行软件、接口协议、运维词典、算法/硬件）。后续文档或代码变更后，应按 traceability.md 的映射定向复核受影响语句。
